namespace Playground
{
    using System;
    using static System.Console;

    public static class Class
    {
        public static string Upper(string s)
        {
            string aux = (null == s) ? null : s.ToUpper();
            return aux;
        }

        public static int Count(string s)
        {
            int length = (null == s) ? null : s.Length;
            return length;
        }

        public static void Main()
        {
            string upper = Upper(@"Markiewicz, Maksymilian");
            Write($"{upper} = {Count(upper)}");
            string lower = (null == upper) ? null : upper.ToLower();
            Write($"{lower} = {Count(lower)}");
            Random rand;
            double example = (null == rand) ? null : rand.NextDouble();
        }
    }
}

