﻿namespace Playground
{
    using System;
    using static System.Console;

    public static class Class
    {
        public static string Upper(string s)
        {
            string aux = s?.ToUpper();
            return aux;
        }

        public static int Count(string s)
        {
            int length = s?.Length;
            return length;
        }

        public static void Main()
        {
            string upper = Upper(@"Markiewicz, Maksymilian");
            Write($"{upper} = {Count(upper)}");
            string lower = upper?.ToLower();
            Write($"{lower} = {Count(lower)}");
            Random rand;
            double example = rand?.NextDouble();
        }
    }
}

