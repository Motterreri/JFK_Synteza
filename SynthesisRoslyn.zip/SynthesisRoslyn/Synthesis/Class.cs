﻿namespace Playground
{
    using System;
    using static System.Console;

    public static class Class
    {
        public static string Upper(string s)
        {
            string aux;
            aux = s?.ToUpper();
            return aux;
        }

        public static int Count(string s)
        {
            int length = s?.Length;
            return length;
        }

        public static void Main()
        {
            string upper = Upper(@"Markiewicz, Maksymilian");
            Write($"{upper} = {Count(upper)}");
            string lower = upper?.ToLower();
            Write($"{lower} = {Count(lower)}");
            Random rand;
            double example = rand?.NextDouble();
            string s = lower?.ToUpper();

            bool? var1;
            bool? var2 = var1 = s?.IsNormalized();
            string aux;
            aux = "Question?" + s?.ToUpper();
            string pom2;
            string pom = "Question?" + s?.ToUpper() + "asfg\"" + f?.ToLower() = pom2;
            string pom3 = "Question?\"";
            return s?.ToUpper();
        }
    }
}

