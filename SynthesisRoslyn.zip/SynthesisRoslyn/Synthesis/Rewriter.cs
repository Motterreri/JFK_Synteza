﻿namespace Synthesis
{
    using System;

    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;

    internal sealed class Rewriter : CSharpSyntaxRewriter
    {
        public override SyntaxNode VisitVariableDeclarator(VariableDeclaratorSyntax node)
        {
            string variable = node.ToString();
            if (variable.Contains("?") && !variable.Contains("null"))
            {
                string wynik = Wynik(variable);
                if(wynik != null)
                    node = node.ReplaceNode(node, SyntaxFactory.VariableDeclarator(
                        identifier: SyntaxFactory.Identifier(wynik)));
            }
            return base.VisitVariableDeclarator(node);
        }

        public override SyntaxNode VisitReturnStatement(ReturnStatementSyntax node)
        {
            var ret = node.Expression.ToString();
            if (ret.Contains("?") && !ret.Contains("null"))
            {
                string wynik = " " + Wynik(ret);
                if (wynik != null)
                    node = node.ReplaceNode(node,
                        SyntaxFactory.ReturnStatement(SyntaxFactory.ParseExpression(wynik)).WithLeadingTrivia(node.GetLeadingTrivia()).WithTrailingTrivia(node.GetTrailingTrivia()));
            }
            return base.VisitReturnStatement(node);
        }

        public override SyntaxNode VisitExpressionStatement(ExpressionStatementSyntax node)
        {
            string expression = node.ToString();
            if (expression.Contains("?") && !expression.Contains("null"))
            {
                string wynik = Wynik(expression);
                if (wynik != null)
                    node = node.ReplaceNode(node, SyntaxFactory.ExpressionStatement(
                        SyntaxFactory.ParseExpression(wynik)).WithLeadingTrivia(node.GetLeadingTrivia()).WithTrailingTrivia(node.GetTrailingTrivia()));
            }
            return base.VisitExpressionStatement(node);
        }

        private string Wynik(string variable)
        {
            variable = variable.Replace(" ", String.Empty);
            variable = variable.Replace(";", String.Empty);

            Char rownosc = '=';
            //temp - przechowuje parametry oddzielone znakiem równości
            string[] temp = variable.Split(rownosc);
            int i;
            for (i = 0; i < temp.Length; i++)
            {
                if (temp[i].Contains("?"))
                    break;
            }
            bool testuj = Test(temp[i]);
            string wynik = null;
            if (testuj)
            {
                Char pytajnik = '?';
                Char plus = '+';
                for(int j = 0; j < temp.Length; j++)
                    if(j != i)
                        wynik = wynik + temp[j] + " = ";
                //temp2 - przechowuje parametry odzielone znakiem plusa parametru temp ze znakiem zapytania
                string[] temp2 = temp[i].Split(plus);
                bool czyTekst;
                for(int k = 0; k < temp2.Length; k++)
                {
                    czyTekst = true;
                    if (temp2[k].Contains("?") && !temp2[k].Contains("\""))
                    {
                        //temp3 - przechowuje fragment kodu ulegający zmianie podzielony na 2 części, element i częśćZKropką
                        string[] temp3 = temp2[k].Split(pytajnik);
                        string czescZKropka = temp3[1];
                        string element = temp3[0];
                        if (temp2.Length > 1)
                        {
                            if (k + 1 == temp2.Length)
                                wynik = wynik + "((null == " + element + ") ? null : " + element + czescZKropka + ")";
                            else
                                wynik = wynik + "((null == " + element + ") ? null : " + element + czescZKropka + ") + ";
                        }
                        else
                            wynik = wynik + "(null == " + element + ") ? null : " + element + czescZKropka;
                        czyTekst = false;
                    }
                    if (czyTekst)
                    {
                        if (k + 1 == temp2.Length)
                            wynik = wynik + temp2[k];
                        else
                            wynik = wynik + temp2[k] + " + ";
                    }
                }   
            }
            return wynik;
        }

        private bool Test(string s)
        {
            Char plus = '+';
            string[] temp = s.Split(plus);
            for(int i = 0; i < temp.Length; i++)
            {
                if(temp[i].Contains("?") && !temp[i].Contains("\""))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
