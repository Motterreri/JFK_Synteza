﻿namespace Synthesis
{
    using System;
    using System.Linq;

    using Microsoft.CodeAnalysis;
    using Microsoft.CodeAnalysis.CSharp;
    using Microsoft.CodeAnalysis.CSharp.Syntax;
    using System.Text;

    internal sealed class Rewriter : CSharpSyntaxRewriter
    {
        public override SyntaxNode VisitVariableDeclarator(VariableDeclaratorSyntax node)
        {
            string variable = node.ToString();
            if (variable.Contains("?") && !variable.Contains("null"))
            {
                variable = variable.Replace(" ", String.Empty);

                Char rownosc = '=';
                Char pytajnik = '?';
                string[] temp = variable.Split(rownosc);
                string[] temp2 = temp[1].Split(pytajnik);
                string nazwaZmiennej = temp[0];
                string czescZKropka = temp2[1];
                string element = temp2[0];
                string wynik = nazwaZmiennej + " = (null == " + element + ") ? null : " + element + czescZKropka;
                node = node.ReplaceNode(node, SyntaxFactory.VariableDeclarator(
                                    identifier: SyntaxFactory.Identifier(wynik)));
            }
            return base.VisitVariableDeclarator(node);
        }
    }
}
